package com.example.demo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface customerRepository extends MongoRepository<customer, String> {
	customer findById(int id);
	customer findByEmail(String email);
	void deleteCustomerById(int id);
	customer saveOrUpdateCustomer(customer Customer);
}
