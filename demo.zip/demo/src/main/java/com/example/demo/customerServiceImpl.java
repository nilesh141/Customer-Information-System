package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.*;
@Service
public class customerServiceImpl implements customerServices{

	@Autowired
	private customerRepository CustomerRepository;
	@Override
	public customer findByEmail(String email) {
		// TODO Auto-generated method stub
		return CustomerRepository.findByEmail(email);
	}
	@Override
	public customer findById(int id) {
		// TODO Auto-generated method stub
		return CustomerRepository.findById(id);
	}

	

	@Override
	public void deleteCustomerById(int id) {
		// TODO Auto-generated method stub
		CustomerRepository.deleteCustomerById(id);
	}

	@Override
	public customer saveOrUpdateCustomer(customer Customer) {
		// TODO Auto-generated method stub
		return CustomerRepository.save(Customer);
	}

	
}
