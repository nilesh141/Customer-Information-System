package com.example.demo;

public interface customerServices {
	customer findByEmail(String email);
	customer findById(int id);
	void deleteCustomerById(int id);
	customer saveOrUpdateCustomer(customer Customer);
}
