package com.example.demo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customers")
public class customer {
    @Id
    private int id;
    private String name;
    private long mobNumber;
    private String email;
    private String city;
   
    public customer() {
    }

    public customer(String name, long mobNumber, String email) {
        this.name = name;
        this.mobNumber = mobNumber;
        this.email = email;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getmobNumber() {
        return mobNumber;
    }

    public void setmobNumber(long mobNumber) {
        this.mobNumber = mobNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", mobNumber=" + mobNumber +
                ", email='" + email + '\'' +
                ", city=" + city +
                '}';
    }

	
}